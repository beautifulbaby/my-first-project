/**
 * @author wangyiheng douban
 */
/**
 * 测试数据
 */

/**
 * 启动Vue
 */
var vue = new Vue({
	el : '#app',
	data : {
		// 初始化默认属性,无登录，未选择电影，没有电影列表,是不是选中了导演
		isLogin : false,
		chooseFilm : false,
		hasFilms : false,
		chooseDirector : false,
		// 选中电影后，一个电影属性展示
		filmName : '',
		filmScore : '',
		filmActors : '',
		filmDirector : '',
		is3D : '',
		filmDescription : '',
		filmPicture : 'picture1.jpg',
		filmType : '',
		filmShowTime : '',
		// 选中的当前电影的id
		filmId : '',
		// 电影列表，推荐列表，排行列表，评论列表
		items : "",
		recommendList : "",
		rankList : "",
		commentList : "",
		// 电影导演属性：
		dirBirth : '',
		dirBirthPlace : '',
		dirId : '',
		dirIntroduction : '',
		dirJob : '',
		dirName : '',
		dirPhoto : 'director1.jpg',
		dirPrize : '',
		// 登录后的用户属性
		userId : '',
		userName : '',
		mobile : '',
		password : '',
		userAccount : '',
		// 注册属性，区别于登录，防止混淆
		registerName : '',
		registerMobile : '',
		registerPassword : '',
		// 个人进行评论的内容
		userComment : '',
		userScore : '',
		// 搜索框内容
		searchInput : '',
		// 充值金额
		amount : '',
	},
	methods : {
		// 前往电影详情页接口
		filmView : function(id) {
			goFilmView(id);
		},
		backFilm : function() {
			this.chooseDirector = false;
		},
		// 根据类型获取电影列表接口
		getFilmsByType : function(type) {
			getFilmsByType(type);
		},
		// 搜索电影功能
		search : function() {
			search(this.searchInput);
		},
		// 提交电影评论方法接口
		comment : function() {
			comment(this.userId);
		},
		// errorInfo接口
		errorInfo : function() {
			errorInfo();
		},
		// 登录方法接口
		login : function() {
			login(this.mobile, this.password);
		},
		// 注册方法接口
		register : function() {
			register();
		},
		// 忘记密码接口
		forgetPassword : function() {

		},
		// 购买电影接口
		buyTicket : function() {
			buyTicket(this.userId,this.filmId, this.userAccount);
		},
		// 查看导演方法接口
		getDirectorByName : function() {
			getDirectorByName(this.filmDirector);
		},
		// 充值金额方法接口
		recharge : function() {
			recharge();
		}
	}
});

/**
 * 页面启动方法
 */
$(function() {
	// 获取电影列表,推荐列表，以及排行列表三个接口
	getAllFilms();
	getUserBySession();
});

/**
 * 错误或者误操作提示
 * 
 * @returns
 */
function errorInfo() {
	Lobibox.notify('info', {
		msg : '暂未开放该功能',
	});
}
/**
 * 获取所有电影列表
 * 
 * @returns map
 */
function getAllFilms() {
	$.ajax({
		url : ctx + '/film/getAllFilms',
		data : {
			"name" : ""
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				vue.items = data.filmList;
				vue.rankList = data.rankList;
				vue.recommendList = data.recommendList;
				vue.hasFilms = true;
			} else {
				vue.hasFilms = false;
			}
		}
	})
}

/**
 * 根据类型加载电影列表
 */
function getFilmsByType(type) {
	// 初始化操作
	vue.items = "";
	vue.chooseFilm = false;
	vue.searchInput = '';
	$.ajax({
		url : ctx + '/film/getFilmsByType',
		data : {
			"type" : type
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			if (data.retCode == 1) {
				vue.items = data.list;
			} else {
				Lobibox.notify('info', {
					msg : '暂无该类型电影',
				});
			}
		}
	})
}

/**
 * 根据搜索内容模糊匹配
 */
function search(name) {
	vue.items = "";
	vue.chooseFilm = false;
	$.ajax({
		url : ctx + '/film/getFilmsByName',
		data : {
			"name" : name
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				vue.items = data.filmList;
				vue.searchInput = "";
			} else {
				Lobibox.notify('info', {
					msg : '暂无匹配电影',
				});
			}
		}
	})
}

/**
 * 电影详情页实现方法
 */
function goFilmView(id) {
	vue.chooseFilm = true;
	vue.searchInput = '';
	vue.chooseDirector = false;
	$.ajax({
		url : ctx + '/film/getFilmById',
		data : {
			"id" : id
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				vue.filmName = data.film.filmName;
				vue.filmScore = data.film.filmScore;
				vue.filmActors = data.film.filmActor;
				vue.filmDirector = data.film.filmDirector;
				vue.is3D = data.film.is3d;
				vue.filmDescription = data.film.filmDescribe;
				vue.filmPicture = data.film.filmPicture;
				vue.filmType = data.film.category;
				vue.filmShowTime = data.film.filmTime;
				vue.filmId = data.film.id;
				loadComment(data.film.id);
			} else {
				Lobibox.notify('error', {
					msg : '无法加载该电影',
				});
			}
		}
	})
}

/**
 * 加载评论
 */
function loadComment(id) {
	vue.commentList = "";
	$.ajax({
		url : ctx + '/comment/getCommentsByFilmId',
		data : {
			"filmId" : id
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				vue.commentList = data.comments;
			}
		}
	})
}

/**
 * 发表评论方法
 */
function comment(id) {

	if (!vue.isLogin) {
		Lobibox.notify('info', {
			msg : '请先登录',
		});
		return;
	}
	// 假设已经登录
	if (vue.userScore >= 10) {
		vue.userScore = 10;
	} else if (vue.userScore <= 0) {
		vue.userScore = 0;
	}
	var comment = {
		"coUserid" : id,
		"coScore" : vue.userScore,
		"coDescribe" : vue.userComment,
		"coFilmid" : vue.filmId
	}
	$.ajax({
		url : ctx + '/comment/saveComment',
		data : comment,
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				goFilmView(vue.filmId);
				vue.userScore = "";
				vue.userComment = "";
				Lobibox.notify('success', {
					msg : '评论成功',
				});
			}
		}
	})
}

/**
 * 用户登录方法：
 */
function login(mobile, password) {
	if (mobile == "" || password == "") {
		Lobibox.notify('info', {
			msg : '请填写完整信息',
		});
		return;
	}
	var user = {
		"mobile" : mobile,
		"userPsw" : password
	}
	$.ajax({
		url : ctx + '/user/login',
		data : user,
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				Lobibox.notify('success', {
					msg : '登录成功',
				});
				vue.userName = data.user.userName;
				vue.isLogin = true;
				vue.userId = data.user.userId;
				vue.userAccount = data.user.balance;
				$("#loginModal").modal('hide');
			} else {
				Lobibox.notify('info', {
					msg : '用户名或密码错误',
				});
			}
		}
	})
}

/**
 * 用户注册方法
 * @returns
 */
function register() {
	if (vue.registerName == "" || vue.registerMobile == ""
			|| vue.registerPassword == "") {
		Lobibox.notify('info', {
			msg : '请填写完整信息',
		});
		return;
	}
	var user = {
		userName : vue.registerName,
		mobile : vue.registerMobile,
		userPsw : vue.registerPassword,
	}
	$.ajax({
		url : ctx + '/user/register',
		data : user,
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				Lobibox.notify('success', {
					msg : '注册成功',
				});
				$("#registerModal").modal('hide');
			}
		}
	})
}

/**
 * 购买电影实现方法
 * @returns
 */
function buyTicket(id, filmId,userAccount) {
	userAccount = parseInt(userAccount);
	if(!vue.isLogin){
		Lobibox.notify('info', {
			msg : '请您先登录',
		});
		return;
	}
	if (userAccount < 1) {
		Lobibox.notify('info', {
			msg : '余额不足，请充值',
		});
		return;
	}
	Lobibox.confirm({ msg : "确认购买？",
		callback : function($this, type, ev) {
			if(type == "yes"){
				watchMovie(id,filmId);
			}
		}
	 });
	
}

/**
 * 观看电影
 * @returns
 */
function watchMovie(id,filmId){
	$.ajax({
		url : ctx + '/film/bookTicket',
		data : {
			"userId" : id,
			"filmId" : filmId
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			if (data.retCode == 1) {
				window.location.href = ctx+'/film/viewOnline';
			}
			else{
				Lobibox.notify('info', {
					msg : data.retMsg,
				});
			}
		}
	})
}
/**
 * 根据导演名称获取导演
 * 
 * @param name
 * @returns
 */
function getDirectorByName(name) {
	vue.chooseDirector = true;
	$.ajax({
		url : ctx + '/director/getDirectorByName',
		data : {
			"name" : name
		},
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			console.log(data);
			vue.dirBirth = data.director.dirBirth;
			vue.dirBirthPlace = data.director.dirBirthplace;
			vue.dirId = data.director.dirId;
			vue.dirIntroduction = data.director.dirIntroduction;
			vue.dirJob = data.director.dirJob;
			vue.dirName = data.director.dirName;
			vue.dirPhoto = data.director.dirPhoto;
			vue.dirPrize = data.director.dirPrize;
		}
	})
}

/**
 * 账户充值
 * 
 * @returns
 */
function recharge() {
	var account = parseInt(vue.amount) + parseInt(vue.userAccount);
	console.log(account);
	var user = {
			userId:vue.userId,
			balance:account
	}
	$.ajax({
		url : ctx + '/user/recharge',
		data : user,
		dataType : 'json',
		type : 'POST',
		success:function(data){
			console.log(data);
			if(data.retCode == 1){
				Lobibox.notify('success', {
					msg : "充值成功",
				});
				vue.userAccount = data.user.balance;
				$("#rechargeModal").modal('hide');
			}
			else {
				Lobibox.notify('error', {
					msg : "充值失败",
				});
			}
		}
	})
}

/**
 * 在session中获取用户
 */
function getUserBySession() {
	$.ajax({
		url : ctx + '/user/getSessionUser',
		dataType : 'json',
		type : 'POST',
		success : function(data) {
			if (data.retCode == 1) {
				vue.userName = data.user.userName;
				vue.isLogin = true;
				vue.userId = data.user.userId;
				vue.userAccount = data.user.balance;
			}
		}
	})
}
