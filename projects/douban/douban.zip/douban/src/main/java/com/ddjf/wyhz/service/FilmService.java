package com.ddjf.wyhz.service;

import java.util.List;

import com.ddjf.wyhz.entity.Film;

public interface FilmService {
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月4日下午2:21:15
     * 参数说明：@return
     * 功能说明：（根据名称模糊查询）获取所有电影
     *
     */
    public List<Film> getAllFilms(String name);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月4日下午2:22:15
     * 参数说明：@param type
     * 参数说明：@return
     * 功能说明：获取对应类型的所有电影
     *
     */
    public List<Film> getFilmsByType(String type);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月5日上午9:41:55
     * 参数说明：@param id
     * 参数说明：@return
     * 功能说明：根据电影Id获取对应电影
     *
     */
    public Film getFilmById(Integer id);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月5日上午9:59:46
     * 参数说明：@return
     * 功能说明：获取推荐列表
     *
     */
    public List<Film> getRecommendList(Integer size);

    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月5日上午9:59:57
     * 参数说明：@return
     * 功能说明：获取排行榜列表
     *
     */
    public List<Film> getRankList(Integer size);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月4日下午3:42:06
     * 参数说明：@param film
     * 参数说明：@return
     * 功能说明：保存电影
     *
     */
    public int saveFilm(Film film);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月4日下午3:42:24
     * 参数说明：@param film
     * 参数说明：@return
     * 功能说明：删除电影
     *
     */
    public int deleteFilm(Film film);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月5日下午3:26:17
     * 参数说明：@param filmId
     * 参数说明：@return
     * 功能说明：计算电影评分
     *
     */
    public void caculateScore(Integer filmId, Double score, Integer size);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月7日下午3:20:00
     * 参数说明：@param userId 用户id
     * 参数说明：@param filmId 电影id
     * 参数说明：@return
     * 功能说明：订票
     *
     */
    public int bookTicket(Integer userId, Integer filmId);
}
