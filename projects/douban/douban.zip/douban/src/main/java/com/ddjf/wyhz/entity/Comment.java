package com.ddjf.wyhz.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Comment {
    private Integer coId;

    private Double coScore;

    private Date coTime;

    private Integer coFilmid;

    private Integer coUserid;

    private String coDescribe;

    public Integer getCoId() {
        return coId;
    }

    public void setCoId(Integer coId) {
        this.coId = coId;
    }

    public Double getCoScore() {
        return coScore;
    }

    public void setCoScore(Double coScore) {
        this.coScore = coScore;
    }

    @JsonFormat(pattern = "yyyy-MM-dd HH-mm-ss")
    public Date getCoTime() {
        return coTime;
    }

    public void setCoTime(Date coTime) {
        this.coTime = coTime;
    }

    public Integer getCoFilmid() {
        return coFilmid;
    }

    public void setCoFilmid(Integer coFilmid) {
        this.coFilmid = coFilmid;
    }

    public Integer getCoUserid() {
        return coUserid;
    }

    public void setCoUserid(Integer coUserid) {
        this.coUserid = coUserid;
    }

    public String getCoDescribe() {
        return coDescribe;
    }

    public void setCoDescribe(String coDescribe) {
        this.coDescribe = coDescribe == null ? null : coDescribe.trim();
    }
}