package com.ddjf.wyhz.dao;

import com.ddjf.wyhz.entity.Director;

public interface DirectorMapper {
    int deleteByPrimaryKey(Integer dirId);

    int insert(Director record);

    int insertSelective(Director record);

    Director selectByPrimaryKey(Integer dirId);

    int updateByPrimaryKeySelective(Director record);

    int updateByPrimaryKey(Director record);

    Director selectByName(String dirName);
}