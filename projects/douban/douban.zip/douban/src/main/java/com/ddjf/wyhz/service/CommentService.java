package com.ddjf.wyhz.service;

import java.util.List;

import org.springframework.ui.ModelMap;

import com.ddjf.wyhz.entity.Comment;

public interface CommentService {
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月4日下午4:09:41
     * 参数说明：@param model
     * 参数说明：@param filmId
     * 参数说明：@return
     * 功能说明：根据电影获取对应所有评论
     *
     */
    public List<Comment> getCommentsByFilmId(Integer filmId);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月4日下午4:31:20
     * 参数说明：@param comment
     * 参数说明：@return
     * 功能说明：save Comment
     *
     */
    public int saveComment(Comment comment);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月7日上午9:26:41
     * 参数说明：@param filmId
     * 功能说明：计算电影评论平均值
     *
     */
    public void caculateScore(Integer filmId);
}
