package com.ddjf.wyhz.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ddjf.wyhz.dao.CommentMapper;
import com.ddjf.wyhz.dao.FilmMapper;
import com.ddjf.wyhz.dao.UserMapper;
import com.ddjf.wyhz.entity.Film;
import com.ddjf.wyhz.entity.User;
import com.ddjf.wyhz.service.CommentService;
import com.ddjf.wyhz.service.FilmService;

@Service
public class FilmServiceImpl implements FilmService {

    @Autowired
    private FilmMapper filmMapper;

    @Autowired
    private UserMapper userMapper;
    
    @Override
    public List<Film> getAllFilms(String name) {
        return filmMapper.getFilmsByName(name);
    }

    @Override
    public List<Film> getFilmsByType(String type) {
        return filmMapper.getFilmsByType(type);
    }

    @Override
    public Film getFilmById(Integer id) {
        return filmMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<Film> getRecommendList(Integer size) {
        List<Film> films = this.getAllFilms("");
        Random random = new Random();
        ArrayList<Integer> list = new ArrayList<Integer>();

        if(size > films.size()){
            return null;
        }
        
        //[0,films.size())范围生成size大小的随机数组
        for (int i = 0; i < size; i++) {
            int number = 0;
            do {
                number = random.nextInt(films.size());
            }
            while (list.contains(number));
            list.add(number);
        }
        
        List<Film> result = new ArrayList<Film>();
        for (Integer i : list) {
            result.add(films.get(i));
        }
        return result;
    }

    @Override
    public List<Film> getRankList(Integer size) {
        List<Film> films = filmMapper.getFilmsOrderByScore();
        if(films.size() < size){
            return null;
        }
        return films.subList(0, size);
    }

    @Override
    public int saveFilm(Film film) {
        if (film.getId() == null || film.getId().equals("")) {
            return filmMapper.insert(film);
        }
        else {
            return filmMapper.updateByPrimaryKeyWithBLOBs(film);
        }
    }

    @Override
    public int deleteFilm(Film film) {
        return filmMapper.deleteByPrimaryKey(film.getId());
    }

    @Override
    public void caculateScore(Integer filmId, Double score, Integer size) {
        Film film = filmMapper.selectByPrimaryKey(filmId);
        Double finalScore = (score + (size - 1) * film.getFilmScore()) / size;
        film.setFilmScore((float)(((int)(finalScore*10))/10.0));
        this.saveFilm(film);
    }

    @Override
    public int bookTicket(Integer userId, Integer filmId) {
        Film film = filmMapper.selectByPrimaryKey(filmId);
        //电影票库存不足
        if(film.getStock() <= 0){
            return 0;
        }
        //用户余额不足
        User user = userMapper.selectById(userId);
        if(user.getBalance() <= 0){
            return 0;
        }
        user.setBalance(user.getBalance() - 1);
        film.setStock(film.getStock() - 1);
        Integer resultFlag = filmMapper.updateByPrimaryKeyWithBLOBs(film);
        if(resultFlag == 0){
            return 0;
        }
        return userMapper.updateByPrimaryKey(user);
    }
}
