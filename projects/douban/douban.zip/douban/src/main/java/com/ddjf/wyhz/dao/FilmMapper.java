package com.ddjf.wyhz.dao;

import java.util.List;

import com.ddjf.wyhz.entity.Film;

public interface FilmMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Film record);

    Film selectByPrimaryKey(Integer id);

    int updateByPrimaryKeyWithBLOBs(Film record);
    
    List<Film> getFilmsByName(String filmName);
    
    List<Film> getFilmsByType(String type);
    
    List<Film> getFilmsOrderByScore();
}