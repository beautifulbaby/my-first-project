package com.ddjf.wyhz.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ddjf.wyhz.entity.Comment;
import com.ddjf.wyhz.entity.Film;
import com.ddjf.wyhz.service.CommentService;
import com.ddjf.wyhz.util.ResultUtil;

@Controller
@RequestMapping("comment")
public class CommentController {

    @Autowired
    private CommentService commentService;

    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月5日下午2:17:53
     * 参数说明：@param request
     * 参数说明：@param filmId
     * 参数说明：@return
     * 功能说明：查询对应电影所有评论
     *
     */
    @RequestMapping(value = "getCommentsByFilmId", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getCommentsByFilmId(HttpServletRequest request,
            Integer filmId) {
        Map<String, Object> map = null;
        List<Comment> comments = commentService.getCommentsByFilmId(filmId);
        if (comments.size() > 0) {
            map = ResultUtil.success();
            map.put("comments", comments);
        }
        else {
            map = ResultUtil.error("暂无评论");
        }
        return map;
    }

    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月5日下午2:53:22
     * 参数说明：@param request
     * 参数说明：@param comment
     * 参数说明：@return
     * 功能说明：保存评论
     *
     */
    @RequestMapping(value = "saveComment", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> saveComment(HttpServletRequest request,
            Comment comment) {
        Map<String, Object> map = null;
        Integer result = commentService.saveComment(comment);
        if (result == 1) {
            map = ResultUtil.success();
        }
        else {
            map = ResultUtil.error("保存失败");
        }
        return map;
    }
}
