package com.ddjf.wyhz.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ddjf.wyhz.entity.User;
import com.ddjf.wyhz.service.UserService;
import com.ddjf.wyhz.util.ResultUtil;
import com.ddjf.wyhz.util.SessionUtil;

/**
 * 
 * 
 * 构建组：大道金服科技部 作者:zhangxiaolu 邮箱:zhangxiaolu@ddjf.com.cn 日期:2017年8月5日下午4:55:08
 * 功能说明：
 *
 */
@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    
    /**
     * 注册
     */
    @RequestMapping(value = "register", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> register(HttpServletRequest request, User user) {
        Map<String, Object> map = null;
        int result = userService.register(user);
        if (result == 1) {
            map = ResultUtil.success();
            map.put("user", user);
            SessionUtil.setUser(request, user);
        }
        else {
            map = ResultUtil.error("登录失败");
        }
        return map;
    }
    
    /**
     * 登录方法
     */
    @RequestMapping(value = "login", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> login(HttpServletRequest request, User user) {
        Map<String, Object> map = null;
        user = userService.login(user);
        if (user != null) {
            map = ResultUtil.success();
            map.put("user", user);
            SessionUtil.setUser(request, user);
        }
        else {
            map = ResultUtil.error("登录失败");
        }
        return map;
    }
    
    /**
     * 在session中获取用户
     */
    @RequestMapping(value = "getSessionUser",method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getSessionUser(HttpServletRequest request){
        Map<String, Object> map= null;
        User user = SessionUtil.getUser(request);
        Integer id = user.getUserId();
        user = userService.getUserById(id);
        if (user != null) {
            map = ResultUtil.success();
            map.put("user", user);
            SessionUtil.setUser(request, user);
        }
        else {
            map = ResultUtil.error("获取失败");
        }
        return map;
    }
    
    /**
     * 账户充值
     */
    @RequestMapping(value = "recharge",method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> recharge(HttpServletRequest request,User user){
        Map<String, Object> map = null;
        int result = userService.recharge(user);
        if(result == 0){
            map = ResultUtil.error();
        }
        else {
            map = ResultUtil.success();
            map.put("user", user);
        }
        return map;
    }
}
