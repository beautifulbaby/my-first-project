package com.ddjf.wyhz.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ddjf.wyhz.entity.Film;
import com.ddjf.wyhz.service.FilmService;
import com.ddjf.wyhz.util.ResultUtil;

@Controller
@RequestMapping("film")
public class FilmController {

    @Autowired
    private FilmService filmService;

    /**
     * 电影播放页面
     */
    @RequestMapping("viewOnline")
    public String goViewOnline(){
        return "/viewOnline";
    }
    
    /**
     * 
     * 
     * 构建组：大道金服科技部 作者:yukan 邮箱:yukan@ddjf.com.cn 日期:2017年8月4日下午3:32:10
     * 参数说明：@param model 参数说明：@param name 电影名称 模糊查询 参数说明：@return 功能说明：根据名称获取电影
     *
     */
    @RequestMapping(value = "getAllFilms", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getAllFilms(HttpServletRequest request,
            String name) {
        // 标志位，记录有没有出错
        Integer errorFlag = 0;

        Map<String, Object> map = null;
        List<Film> list = filmService.getAllFilms(name);
        if (list.size() > 0) {
            map = ResultUtil.success();
            map.put("filmList", list);
        }
        else {
            errorFlag = 1;
        }
        // 获取推荐列表
        List<Film> recommendList = filmService.getRecommendList(5);
        if (recommendList != null && recommendList.size() > 0) {
            map.put("recommendList", recommendList);
        }
        else {
            errorFlag = 1;
        }

        // 获取评分排行榜
        List<Film> rankList = filmService.getRankList(5);
        if (rankList != null && rankList.size() > 0) {
            map.put("rankList", rankList);
        }
        else {
            errorFlag = 1;
        }
        if (errorFlag == 1) {
            map = ResultUtil.error("获取列表异常");
        }
        return map;
    }
    
    /**
     * 
     * 
     * 构建组：大道金服科技部 作者:yukan 邮箱:yukan@ddjf.com.cn 日期:2017年8月4日下午3:32:10
     * 参数说明：@param model 参数说明：@param name 电影名称 模糊查询 参数说明：@return 功能说明：根据名称获取电影
     *
     */
    @RequestMapping(value = "getFilmsByName", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getFilmsByName(HttpServletRequest request,
            String name) {
        Map<String, Object> map = null;
        List<Film> list = filmService.getAllFilms(name);
        if (list.size() > 0) {
            map = ResultUtil.success();
            map.put("filmList", list);
        }
        else {
            map = ResultUtil.error("获取列表异常");
        }
        return map;
    }

    /**
     * 
     * 
     * 构建组：大道金服科技部 作者:yukan 邮箱:yukan@ddjf.com.cn 日期:2017年8月4日下午3:34:25
     * 参数说明：@param model 参数说明：@param type 电影类型 参数说明：@return 功能说明：根据电影类型获取电影列表
     *
     */
    @RequestMapping(value = "getFilmsByType", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getFilmsByType(HttpServletRequest request,
            String type) {
        Map<String, Object> map = null;
        List<Film> list = filmService.getFilmsByType(type);
        if (list.size() > 0) {
            map = ResultUtil.success();
            map.put("list", list);
        }
        else {
            map = ResultUtil.error("暂无电影");
        }
        return map;
    }

    /**
     * 
     * 
     * 构建组：大道金服科技部 作者:yukan 邮箱:yukan@ddjf.com.cn 日期:2017年8月5日上午9:46:04
     * 参数说明：@param req 参数说明：@param id filmId 参数说明：@return 功能说明：根据电影Id获取对应电影
     *
     */
    @RequestMapping(value = "getFilmById", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getFilmById(HttpServletRequest req, Integer id) {
        Map<String, Object> map = null;
        Film film = filmService.getFilmById(id);
        if (film == null || film.equals("")) {
            map = ResultUtil.error("无此电影");
        }
        else {
            map = ResultUtil.success();
            map.put("film", film);
        }
        return map;
    }

    /**
     * 
     * 
     * 构建组：大道金服科技部 作者:yukan 邮箱:yukan@ddjf.com.cn 日期:2017年8月5日上午10:51:03
     * 参数说明：@param req 参数说明：@return 功能说明：获取size为5的推荐列表
     *
     */
    @RequestMapping(value = "getRecommendList", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> getRecommendList(HttpServletRequest req) {
        Map<String, Object> map = null;
        List<Film> recommendList = filmService.getRecommendList(5);
        if (recommendList != null && recommendList.size() > 0) {
            map = ResultUtil.success();
            map.put("recommendList", recommendList);
        }
        else {
            map = ResultUtil.error("生成推荐列表失败");
        }
        return map;
    }
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月7日下午3:47:51
     * 参数说明：@param req
     * 参数说明：@param userId
     * 参数说明：@param filmId
     * 参数说明：@return
     * 功能说明：订票
     *
     */
    @RequestMapping(value = "bookTicket", method = RequestMethod.POST)
    @ResponseBody
    public Map<String, Object> bookTicket(HttpServletRequest req, Integer userId, Integer filmId) {
        Map<String, Object> map = null;
       Integer result = filmService.bookTicket(userId, filmId);
        if (result != 0) {
            map = ResultUtil.success();
        }
        else {
            map = ResultUtil.error("订票失败");
        }
        return map;
    }
}
