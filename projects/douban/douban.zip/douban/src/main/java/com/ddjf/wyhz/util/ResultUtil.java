package com.ddjf.wyhz.util;

import java.util.HashMap;
import java.util.Map;

public class ResultUtil {
	
	public static Map<String, Object> success(){
		Map<String, Object> map = new HashMap<>();
		map.put("retCode", "1");
		map.put("retMsg", "成功");
		return map;
	}
	
	public static Map<String, Object> error(){
		return error("失败");
	}
	
	public static Map<String, Object> error(String retMsg){
		return error("2", retMsg);
	}
	
	public static Map<String, Object> error(String retCode, String retMsg){
		Map<String, Object> map = new HashMap<>();
		map.put("retCode", retCode);
		map.put("retMsg", retMsg);
		return map;
	}
	
	
}
