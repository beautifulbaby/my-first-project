package com.ddjf.wyhz.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ddjf.wyhz.dao.DirectorMapper;
import com.ddjf.wyhz.entity.Director;
import com.ddjf.wyhz.service.DirectorService;

@Service
public class DirectorServiceImpl implements DirectorService {
    
    @Autowired
    private DirectorMapper directorMapper;

    @Override
    public Director getDirectorByName(String name) {
        return directorMapper.selectByName(name.trim());
    }

}
