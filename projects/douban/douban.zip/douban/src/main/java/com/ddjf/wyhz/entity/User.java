package com.ddjf.wyhz.entity;
/**
 * 用户类
 * 
 * 构建组：大道金服科技部
 * 作者:zhangxiaolu
 * 邮箱:zhangxiaolu@ddjf.com.cn
 * 日期:2017年8月5日上午10:15:00
 * 功能说明：
 *
 */
public class User {
    private Integer userId;
    private String userName;
    private String userPsw;
    private Integer balance;
    private String mobile;
    
    public Integer getUserId(){
        return userId;
    }
    
    public void setUserId(Integer userId){
        this.userId=userId;
    }
    
    public String getUserName(){
        return userName;
    }
    
    public void setUserName(String userName){
        this.userName=userName;
    }
    
    public String getUserPsw(){
        return userPsw;
    }
    
    public void setUserPsw(String userPsw){
        this.userPsw= userPsw == null ? null : userPsw.trim();
    }

    public Integer getBalance() {
        return balance;
    }

    public void setBalance(Integer balance) {
        this.balance = balance;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    

}
