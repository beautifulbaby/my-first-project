package com.ddjf.wyhz.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Director {
    private Integer dirId;

    private String dirName;

    private String dirPhoto;

    private Date dirBirth;

    private String dirBirthplace;

    private String dirJob;

    private String dirIntroduction;

    private String dirPrize;

    public Integer getDirId() {
        return dirId;
    }

    public void setDirId(Integer dirId) {
        this.dirId = dirId;
    }

    public String getDirName() {
        return dirName;
    }

    public void setDirName(String dirName) {
        this.dirName = dirName == null ? null : dirName.trim();
    }

    public String getDirPhoto() {
        return dirPhoto;
    }

    public void setDirPhoto(String dirPhoto) {
        this.dirPhoto = dirPhoto == null ? null : dirPhoto.trim();
    }

    @JsonFormat(pattern = "yyyy-MM-dd")
    public Date getDirBirth() {
        return dirBirth;
    }

    public void setDirBirth(Date dirBirth) {
        this.dirBirth = dirBirth;
    }

    public String getDirBirthplace() {
        return dirBirthplace;
    }

    public void setDirBirthplace(String dirBirthplace) {
        this.dirBirthplace = dirBirthplace == null ? null : dirBirthplace.trim();
    }

    public String getDirJob() {
        return dirJob;
    }

    public void setDirJob(String dirJob) {
        this.dirJob = dirJob == null ? null : dirJob.trim();
    }
    
    public String getDirIntroduction() {
        return dirIntroduction;
    }

    public void setDirIntroduction(String dirIntroduction) {
        this.dirIntroduction = dirIntroduction == null ? null : dirIntroduction.trim();
    }

    public String getDirPrize() {
        return dirPrize;
    }

    public void setDirPrize(String dirPrize) {
        this.dirPrize = dirPrize == null ? null : dirPrize.trim();
    }
}