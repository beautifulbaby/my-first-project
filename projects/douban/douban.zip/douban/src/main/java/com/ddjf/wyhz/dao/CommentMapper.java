package com.ddjf.wyhz.dao;

import java.util.List;

import com.ddjf.wyhz.entity.Comment;

public interface CommentMapper {
    int deleteByPrimaryKey(Integer coId);

    int insert(Comment record);

    int insertSelective(Comment record);

    Comment selectByPrimaryKey(Integer coId);

    int updateByPrimaryKeySelective(Comment record);

    int updateByPrimaryKeyWithBLOBs(Comment record);

    int updateByPrimaryKey(Comment record);
    
    List<Comment> selectByFilmId(Integer filmId);
}