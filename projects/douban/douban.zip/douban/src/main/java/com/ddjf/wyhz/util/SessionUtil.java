package com.ddjf.wyhz.util;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import com.ddjf.wyhz.entity.User;

//import com.ddjf.app.entity.Customer;

/**
 * 
 * 
 * 构建组：大道金服科技部
 * 作者:wangyiheng
 * 邮箱:wangyiheng@ddjf.com.cn
 * 日期:2017年7月31日下午3:26:45
 * 功能说明：封装饿了么中用于存放在session中的一些用户信息等
 *
 */
public class SessionUtil {
   /*
    private static final String KEY_CUSTOMER = "customer";
    
    */
    private static final String KEY_USER = "user";
    /**
     * 获取当前用户
     * @Param request
     */
    public static User getUser(HttpServletRequest request) {
        return (User)request.getSession().getAttribute(KEY_USER);
    }
    /*
    public static Customer getCustomer(HttpServletRequest request) {
        return (Customer)request.getSession().getAttribute(KEY_CUSTOMER);
    }
    
    *//**
     * 设置当前用户
     * @Param request
     * @Param customer
     */
        public static void setUser(HttpServletRequest request,User user) {
            request.getSession().setAttribute(KEY_USER, user); 
        }
        /*
    public static void setCustomer(HttpServletRequest request,Customer customer) {
        request.getSession().setAttribute(KEY_CUSTOMER, customer);
    }*/
}
