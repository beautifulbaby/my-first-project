package com.ddjf.wyhz.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ddjf.wyhz.service.CommentService;
import com.ddjf.wyhz.service.FilmService;
import com.ddjf.wyhz.service.UserService;

@Controller
@RequestMapping("/admin")
public class AdminController {
    @Resource
    private UserService userService;
    @Resource
    private FilmService filmService;
    @Resource
    private CommentService commentService;
    
    @RequestMapping("")
    public String adminView(){
        return "/adminView";
    }
    
    @RequestMapping(value="submit",method=RequestMethod.POST)
    public String submit(String username,String password,HttpServletRequest request){
        String name = request.getParameter(username);
        
        
        return "";
    }
}
