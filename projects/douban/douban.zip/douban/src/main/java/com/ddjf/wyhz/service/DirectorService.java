package com.ddjf.wyhz.service;

import com.ddjf.wyhz.entity.Director;

public interface DirectorService {
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月7日上午11:36:39
     * 参数说明：@param name
     * 参数说明：@return
     * 功能说明：根据导演姓名获取导演详细信息
     *
     */
    public Director getDirectorByName(String name);
}
