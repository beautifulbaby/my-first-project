package com.ddjf.wyhz.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Film {
    private Integer id;

    private String filmName;

    private String filmActor;

    private String is3d;

    private String filmPicture;

    private String category;

    private Date filmTime;

    private float filmScore;

    private String filmDescribe;
    
    private String filmDirector;
    
    private Integer stock;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFilmName() {
        return filmName;
    }

    public void setFilmName(String filmName) {
        this.filmName = filmName == null ? null : filmName.trim();
    }

    public String getFilmActor() {
        return filmActor;
    }

    public void setFilmActor(String filmActor) {
        this.filmActor = filmActor == null ? null : filmActor.trim();
    }

    public String getIs3d() {
        return is3d;
    }

    public void setIs3d(String is3d) {
        this.is3d = is3d == null ? null : is3d.trim();
    }

    public String getFilmPicture() {
        return filmPicture;
    }

    public void setFilmPicture(String filmPicture) {
        this.filmPicture = filmPicture == null ? null : filmPicture.trim();
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category == null ? null : category.trim();
    }

    @JsonFormat(pattern = "yyyy-MM-dd")
    public Date getFilmTime() {
        return filmTime;
    }

    public void setFilmTime(Date filmTime) {
        this.filmTime = filmTime;
    }

    public float getFilmScore() {
        return filmScore;
    }

    public void setFilmScore(float filmScore) {
        this.filmScore = filmScore;
    }

    public String getFilmDescribe() {
        return filmDescribe;
    }

    public void setFilmDescribe(String filmDescribe) {
        this.filmDescribe = filmDescribe == null ? null : filmDescribe.trim();
    }
    
    public String getFilmDirector() {
        return filmDirector;
    }

    public void setFilmDirector(String filmDirector) {
        this.filmDirector = filmDirector == null ? null : filmDirector;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }
}