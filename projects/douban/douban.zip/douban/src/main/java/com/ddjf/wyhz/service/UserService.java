package com.ddjf.wyhz.service;

import javax.servlet.http.HttpSession;

import com.ddjf.wyhz.entity.User;

/**
 * 
 * 
 * 构建组：大道金服科技部
 * 作者:zhangxiaolu
 * 邮箱:zhangxiaolu@ddjf.com.cn
 * 日期:2017年8月5日下午3:31:33
 * 功能说明：
 *
 */
public interface UserService {
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:wangyiheng
     * 邮箱:wangyiheng@ddjf.com.cn
     * 日期:2017年8月7日下午6:27:35
     * 参数说明：@param user
     * 参数说明：@return
     * 功能说明：
     *
     */
    public User login(User user);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:wangyiheng
     * 邮箱:wangyiheng@ddjf.com.cn
     * 日期:2017年8月7日下午6:27:42
     * 参数说明：@param user
     * 参数说明：@return
     * 功能说明：
     *
     */
    public int register(User user);

    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:yukan
     * 邮箱:yukan@ddjf.com.cn
     * 日期:2017年8月7日下午5:56:01
     * 参数说明：@param amount
     * 参数说明：@return
     * 功能说明：用户账户充值
     *
     */
    public int recharge(User user);
    
    /**
     * 
     * 
     * 构建组：大道金服科技部
     * 作者:wangyiheng
     * 邮箱:wangyiheng@ddjf.com.cn
     * 日期:2017年8月7日下午6:28:19
     * 参数说明：@param id
     * 参数说明：@return
     * 功能说明：
     *
     */
    public User getUserById(Integer id);
}
