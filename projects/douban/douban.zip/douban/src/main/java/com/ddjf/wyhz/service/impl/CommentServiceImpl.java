package com.ddjf.wyhz.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.ddjf.wyhz.dao.CommentMapper;
import com.ddjf.wyhz.entity.Comment;
import com.ddjf.wyhz.entity.Film;
import com.ddjf.wyhz.service.CommentService;
import com.ddjf.wyhz.service.FilmService;
@Service
public class CommentServiceImpl implements CommentService {
    
    @Autowired
    private CommentMapper commentMapper;
    
    @Autowired
    private FilmService filmService;
    
    @Override
    public List<Comment> getCommentsByFilmId(Integer filmId){
        return commentMapper.selectByFilmId(filmId);
    }

    @Override
    public int saveComment(Comment comment) {
        int result = 0;
        comment.setCoScore((double)((int)(comment.getCoScore()*10))/10);
        //保存
        if(comment.getCoId() == null || comment.getCoId().equals("")){
            result = commentMapper.insert(comment);
        }else{
            result = commentMapper.updateByPrimaryKeyWithBLOBs(comment);
        }
        //filmService.caculateScore(comment.getCoFilmid(), comment.getCoScore(), this.getCommentsByFilmId(comment.getCoFilmid()).size());
        this.caculateScore(comment.getCoFilmid());
        
        return result;
    }
    
    @Override
    public void caculateScore(Integer filmId) {
        Film film = filmService.getFilmById(filmId);
        List<Comment> comments = this.getCommentsByFilmId(filmId);
        Double finalScore = 0.0;
        for (Comment comment : comments) {
            finalScore += comment.getCoScore();
        }
        finalScore = finalScore / comments.size();
        film.setFilmScore((float)(((int)(finalScore*10))/10.0));
        filmService.saveFilm(film);
    }

}
