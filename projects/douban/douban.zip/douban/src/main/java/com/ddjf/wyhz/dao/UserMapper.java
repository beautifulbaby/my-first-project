package com.ddjf.wyhz.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ddjf.wyhz.entity.User;

public interface UserMapper {
    /*public int insert(User record);

    public User selectByUsername(String username);

    public List<User> pageQueryUser(@Param("start") int start,
            @Param("limit") int limit);
     */
    User selectById(Integer userId);
    
    int updateByPrimaryKey(User user);

    User login(User user);
    
    int  insert(User user);
}
