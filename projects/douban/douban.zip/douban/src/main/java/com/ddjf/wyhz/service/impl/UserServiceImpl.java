package com.ddjf.wyhz.service.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ddjf.wyhz.dao.UserMapper;
import com.ddjf.wyhz.entity.User;
import com.ddjf.wyhz.service.UserService;
import com.ddjf.wyhz.util.SessionUtil;

/**
 * 
 * 
 * 构建组：大道金服科技部
 * 作者:zhangxiaolu
 * 邮箱:zhangxiaolu@ddjf.com.cn
 * 日期:2017年8月5日下午3:35:53
 * 功能说明：
 *
 */
@Service
public class UserServiceImpl implements UserService{
    
    @Autowired
    private UserMapper usermapper;

    @Override
    public User login(User user) {
        // TODO Auto-generated method stub
        return usermapper.login(user);
    }

    @Override
    public int register(User user) {
        // TODO Auto-generated method stub
        return usermapper.insert(user);
    }

    @Override
    public int recharge(User user) {
        return usermapper.updateByPrimaryKey(user);
    }

    @Override
    public User getUserById(Integer id) {
        // TODO Auto-generated method stub
        return usermapper.selectById(id);
    }
    
}
