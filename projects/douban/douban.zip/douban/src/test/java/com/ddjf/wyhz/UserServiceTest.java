package com.ddjf.wyhz;
/**
 * 
 * 
 * 构建组：大道金服科技部
 * 作者:zhangxiaolu
 * 邮箱:zhangxiaolu@ddjf.com.cn
 * 日期:2017年8月5日下午7:28:57
 * 功能说明：
 *
 */

import javax.servlet.http.HttpSession;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ddjf.wyhz.entity.User;
import com.ddjf.wyhz.service.UserService;

public class UserServiceTest extends BaseTestCase {
    
    @Autowired
    private UserService userService;
    
    /*@Test
    public void testRegister(){
        System.out.println("---------------------分割线-----------------------------");
        System.out.println("用户注册测试");
        User user=new User();
        user.setUserId(100);
        user.setUserName("s");
        user.setUserPsw("1223");
        boolean result=userService.register("s", "1223");
        System.out.println("测试结果："+result);
        
    }
    
   // @Test
    public void testLogin(){
        System.out.println("---------------------分割线-----------------------------");
        System.out.println("用户登录测试");
        User user=new User();
        user.setUserName("zxl");
        user.setUserPsw("111111");
        boolean result=userService.login("zxl", "111111");
        System.out.println("测试结果："+result);
    }
    */
    
    //@Test
    public void testLogin(){
        System.out.println("---------------------分割线-----------------------------");
        System.out.println("用户登录测试");
        User user=new User();
        user.setMobile("10086");
        user.setUserPsw("123456");
        user = userService.login(user);
        System.out.println(user.getUserName());
    }
    
    @Test
    public void testRegister(){
        System.out.println("---------------------分割线-----------------------------");
        System.out.println("用户测试");
        User user = new User();
        user.setMobile("1008611");
        user.setUserPsw("123456");
        user.setUserName("wyh2");
        int result = userService.register(user);
        System.out.println(result);
    }
}
