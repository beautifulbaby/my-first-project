package com.ddjf.wyhz;

import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ddjf.wyhz.entity.Film;
import com.ddjf.wyhz.service.FilmService;

public class FilmServiceTest extends BaseTestCase{
    
    @Autowired
    private FilmService filmService;

    //@Test
    public void testGetAllFilms() {
        System.out.println("----------------------------------------分割线----------------------------------------");
        System.out.println("测试获取电影列表（输入为空）");
        List<Film> films = filmService.getAllFilms("");
        if (films.size() == 0) {
            System.out.println("no result.");
        }
        else {
            for (Film film : films) {
                System.out.println(film.getFilmName() + " " + film.getFilmDescribe());
            }
        }
        System.out.println("----------------------------------------分割线----------------------------------------"); 
        System.out.println("测试获取电影列表（输入test）");
        films = filmService.getAllFilms("test");
        if (films.size() == 0) {
            System.out.println("no result.");
        }
        else {
            for (Film film : films) {
                System.out.println(film.getFilmName() + " " + film.getFilmDescribe());
            }
        }
    }

    //@Test
    public void testGetFilmsByType() {
        System.out.println("----------------------------------------分割线----------------------------------------"); 
        System.out.println("测试获取电影列表（根据类型，输入为type1）");
        List<Film> films = filmService.getFilmsByType("type1");
        if (films.size() == 0) {
            System.out.println("no result.");
        }
        else {
            for (Film film : films) {
                System.out.println(film.getFilmName() + " " + film.getFilmDescribe());
            }
        }
    }
    
    //@Test
    public void testGetFilmById() {
        System.out.println("----------------------------------------分割线----------------------------------------"); 
        Film film = filmService.getFilmById(3);
        System.out.println(film.getFilmName());
        System.out.println("----------------------------------------分割线----------------------------------------"); 
    }

   //@Test
    public void testGetRecommendList() {
        System.out.println("----------------------------------------分割线----------------------------------------"); 
        List<Film> films = filmService.getRankList(5);
        for (Film film : films) {
            System.out.println(film.getFilmName());
        }
        System.out.println("----------------------------------------分割线----------------------------------------"); 
    }

    //@Test
    public void testGetRankList() {
        System.out.println("----------------------------------------分割线----------------------------------------"); 
        List<Film> films = filmService.getRecommendList(5);
        for (Film film : films) {
            System.out.println(film.getFilmName());
        }
        System.out.println("----------------------------------------分割线----------------------------------------"); 
    }
    
    //@Test
    public void testCaculateScore(){
        filmService.caculateScore(1, 8.00, 2);
        System.out.println(filmService.getFilmById(1).getFilmScore());
    }
    
    @Test
    public void testBookTicket(){
        System.out.println(filmService.bookTicket(12, 2));
    }

}
