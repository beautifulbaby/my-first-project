package com.ddjf.wyhz;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ddjf.wyhz.entity.Comment;
import com.ddjf.wyhz.entity.Film;
import com.ddjf.wyhz.service.CommentService;

public class CommentServiceTest extends BaseTestCase{

    @Autowired
    private CommentService commentService;

    @Test
    public void testGetCommentsByFilmId() {
        List<Comment> comments = commentService.getCommentsByFilmId(1);
        if (comments.size() == 0) {
            System.out.println("no result.");
        }
        else {
            for (Comment comment : comments) {
                System.out.println(comment.getCoDescribe() + " " + comment.getCoScore());
            }
        }
    }

    //@Test
    public void testSaveComment() {
        fail("Not yet implemented");
    }

}
