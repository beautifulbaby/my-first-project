package com.ddjf.wyhz;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.ddjf.wyhz.dao.DirectorMapper;
import com.ddjf.wyhz.entity.Director;
import com.ddjf.wyhz.service.DirectorService;

public class DirectorServiceTest extends BaseTestCase{

    @Autowired 
    private DirectorService directorService;
    @Test
    public void test() {
        Director director = directorService.getDirectorByName("吴京");
        System.out.println(director.getDirBirthplace() + " " + director.getDirIntroduction() + " " + director.getDirJob() + " " + director.getDirName() + " " + director.getDirPrize());
    }

}
